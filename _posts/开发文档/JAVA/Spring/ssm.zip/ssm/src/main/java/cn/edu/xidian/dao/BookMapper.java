package cn.edu.xidian.dao;

import cn.edu.xidian.domain.Books;

import java.util.List;

public interface BookMapper {

    //增加书籍
    int addBooks(Books books);

    //删除书籍
    int deleteBookById(int id);


    //更新书籍
    int updateBooks(Books books);

    //查询一本书籍
    Books queryBookById(int id);

    //查询所有书籍
    List<Books> queryBooks();

    //根据名称搜索书籍
    Books searchBookByName(String name);
}
