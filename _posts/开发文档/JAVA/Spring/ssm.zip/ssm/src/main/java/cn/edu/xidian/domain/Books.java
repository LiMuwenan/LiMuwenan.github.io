package cn.edu.xidian.domain;

public class Books {
    private int book_id;
    private String book_name;
    private int book_nums;
    private String book_detail;

    public Books() {
    }

    public Books(int book_id, String book_name, int book_nums, String book_detail) {
        this.book_id = book_id;
        this.book_name = book_name;
        this.book_nums = book_nums;
        this.book_detail = book_detail;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public int getBook_nums() {
        return book_nums;
    }

    public void setBook_nums(int book_nums) {
        this.book_nums = book_nums;
    }

    public String getBook_detail() {
        return book_detail;
    }

    public void setBook_detail(String book_detail) {
        this.book_detail = book_detail;
    }

    @Override
    public String toString() {
        return "books{" +
                "book_id=" + book_id +
                ", book_name='" + book_name + '\'' +
                ", book_nums=" + book_nums +
                ", book_detail='" + book_detail + '\'' +
                '}';
    }
}
