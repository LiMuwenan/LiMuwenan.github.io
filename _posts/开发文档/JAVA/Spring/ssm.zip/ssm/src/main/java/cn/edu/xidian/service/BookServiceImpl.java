package cn.edu.xidian.service;

import cn.edu.xidian.dao.BookMapper;
import cn.edu.xidian.domain.Books;

import java.util.List;

public class BookServiceImpl implements BookService{
    //service调用dao

    private BookMapper bookMapper;

    public BookServiceImpl() {
    }

    public BookServiceImpl(BookMapper bookMapper) {
        this.bookMapper = bookMapper;
    }

    public BookMapper getBookMapper() {
        return bookMapper;
    }

    public void setBookMapper(BookMapper bookMapper) {
        this.bookMapper = bookMapper;
    }

    @Override
    public int addBooks(Books books) {
        return bookMapper.addBooks(books);
    }

    @Override
    public int deleteBookById(int id) {
        return bookMapper.deleteBookById(id);
    }

    @Override
    public int updateBooks(Books books) {
        return bookMapper.updateBooks(books);
    }

    @Override
    public Books queryBookById(int id) {
        return bookMapper.queryBookById(id);
    }

    @Override
    public List<Books> queryBooks() {
        return bookMapper.queryBooks();
    }

    @Override
    public Books searchBookByName(String name) {
        return bookMapper.searchBookByName(name);
    }


}
