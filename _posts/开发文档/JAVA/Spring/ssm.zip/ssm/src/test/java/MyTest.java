import cn.edu.xidian.domain.Books;
import cn.edu.xidian.service.BookService;
import cn.edu.xidian.service.BookServiceImpl;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class MyTest {
    @Test
    public void test(){
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        BookService bookService = (BookService)context.getBean("bookServiceImpl");
        System.out.println("开始查询");
        Books cpp = bookService.searchBookByName("cpp");
        System.out.println("查询结束");
        System.out.println(cpp);
    }
}
